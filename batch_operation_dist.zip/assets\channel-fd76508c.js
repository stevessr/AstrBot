import{C as r,D as a}from"./mermaid.core-71e668b8.js";const s=(n,o)=>r.lang.round(a.parse(n)[o]),e=s;export{e as c};
