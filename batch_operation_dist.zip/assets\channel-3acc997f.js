import{C as r,D as a}from"./mermaid.core-7b10a030.js";const s=(n,o)=>r.lang.round(a.parse(n)[o]),e=s;export{e as c};
